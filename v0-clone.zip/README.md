# 🤖 AI Code Generator

A powerful AI-powered code generator built with Next.js that creates React applications based on natural language prompts.

## ✨ Features

- 🚀 **AI Code Generation** - Generate React components from natural language descriptions
- 👀 **Live Preview** - See your generated code in action immediately
- 🎨 **Multiple Templates** - Landing pages, todo apps, calculators, weather apps, blogs, and portfolios
- 📱 **Responsive Design** - All generated components are mobile-friendly
- 💻 **Clean Code** - Well-structured, readable code output
- 🔄 **Real-time Updates** - Instant preview updates as you generate

## 🛠️ Tech Stack

- **Frontend**: Next.js 14, React 18, TypeScript
- **Styling**: Tailwind CSS, Custom CSS
- **AI Integration**: OpenAI API (optional)
- **Deployment**: Vercel

## 🚀 Quick Start

### 1. Clone the Repository

\`\`\`bash
git clone https://github.com/yourusername/ai-code-generator.git
cd ai-code-generator
\`\`\`

### 2. Install Dependencies

\`\`\`bash
npm install
\`\`\`

### 3. Environment Setup

Copy the environment file and add your API keys:

\`\`\`bash
cp .env.local.example .env.local
\`\`\`

Edit \`.env.local\` and add your OpenAI API key (optional):

\`\`\`env
OPENAI_API_KEY=sk-proj-your-key-here
\`\`\`

### 4. Run Development Server

\`\`\`bash
npm run dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) in your browser.

## 📖 Usage

1. **Enter a Prompt**: Describe what you want to build
   - "Create a landing page for a startup"
   - "Build a todo app with React"
   - "Make a calculator app"

2. **Generate Code**: Click the "Generate Code" button

3. **View Results**: See both the live preview and generated code

4. **Copy & Use**: Copy the code to use in your projects

## 🎯 Supported Project Types

- **Landing Pages** - Marketing websites with hero sections and features
- **Todo Apps** - Task management with priorities and filters
- **Calculators** - Functional calculators with operations
- **Weather Apps** - Weather dashboards with city search
- **Blogs** - Article listings with categories and search
- **Portfolios** - Developer portfolios with projects showcase
- **Custom Apps** - Counter apps and interactive components

## 🔧 Configuration

### API Integration

The app works without an OpenAI API key using built-in templates. To enable AI-powered generation:

1. Get an API key from [OpenAI](https://platform.openai.com/api-keys)
2. Add it to your \`.env.local\` file
3. Restart the development server

### Customization

- **Templates**: Modify generators in \`app/api/generate/route.ts\`
- **Styling**: Update CSS in \`app/globals.css\`
- **Components**: Add new components in the \`components\` folder

## 📦 Deployment

### Deploy to Vercel

1. Push your code to GitHub
2. Connect your repository to [Vercel](https://vercel.com)
3. Add environment variables in Vercel dashboard
4. Deploy automatically

### Manual Deployment

\`\`\`bash
npm run build
npm start
\`\`\`

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: \`git checkout -b feature/amazing-feature\`
3. Commit changes: \`git commit -m 'Add amazing feature'\`
4. Push to branch: \`git push origin feature/amazing-feature\`
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with [Next.js](https://nextjs.org/)
- Powered by [OpenAI](https://openai.com/) (optional)
- Deployed on [Vercel](https://vercel.com/)

## 📞 Support

If you have any questions or need help:

- Open an issue on GitHub
- Check the documentation
- Contact the maintainers

---

**Happy Coding!** 🎉
\`\`\`
`
