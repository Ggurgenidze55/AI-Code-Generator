import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { prompt } = await request.json()

    if (!prompt?.trim()) {
      return NextResponse.json({ error: "Prompt is required", success: false }, { status: 400 })
    }

    // Generate different components based on prompt keywords
    const lowerPrompt = prompt.toLowerCase()
    let code = ""
    let preview = ""

    if (lowerPrompt.includes("landing") || lowerPrompt.includes("homepage") || lowerPrompt.includes("startup")) {
      // Landing Page Generator
      code = generateLandingPageCode(prompt)
      preview = generateLandingPagePreview(prompt)
    } else if (lowerPrompt.includes("todo") || lowerPrompt.includes("task")) {
      // Todo App Generator
      code = generateTodoAppCode()
      preview = generateTodoAppPreview()
    } else if (lowerPrompt.includes("calculator")) {
      // Calculator Generator
      code = generateCalculatorCode()
      preview = generateCalculatorPreview()
    } else if (lowerPrompt.includes("weather")) {
      // Weather App Generator
      code = generateWeatherAppCode()
      preview = generateWeatherAppPreview()
    } else if (lowerPrompt.includes("blog")) {
      // Blog Generator
      code = generateBlogCode()
      preview = generateBlogPreview()
    } else if (lowerPrompt.includes("portfolio")) {
      // Portfolio Generator
      code = generatePortfolioCode()
      preview = generatePortfolioPreview()
    } else {
      // Default Counter App
      code = generateCounterCodeFunc(prompt)
      preview = generateCounterPreviewFunc(prompt)
    }

    return NextResponse.json({
      code,
      preview,
      success: true,
    })
  } catch (error) {
    console.error("API Error:", error)
    return NextResponse.json(
      {
        error: "Internal server error. Please try again.",
        success: false,
      },
      { status: 500 },
    )
  }
}

function generateLandingPageCode(prompt: string): string {
  return `'use client'
import { useState } from 'react'

export default function LandingPage() {
  const [email, setEmail] = useState('')
  const [subscribed, setSubscribed] = useState(false)

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault()
    if (email.trim()) {
      setSubscribed(true)
    }
  }

  return (
    <div style={{ 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    }}>
      {/* Navigation */}
      <nav style={{ 
        padding: '20px 40px', 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        background: 'rgba(255,255,255,0.1)',
        backdropFilter: 'blur(10px)'
      }}>
        <div style={{ 
          fontSize: '24px', 
          fontWeight: 'bold', 
          color: 'white' 
        }}>
          🚀 ${prompt.includes("startup") ? "StartupName" : "YourBrand"}
        </div>
        <div style={{ display: 'flex', gap: '30px' }}>
          <a href="#features" style={{ color: 'white', textDecoration: 'none' }}>Features</a>
          <a href="#pricing" style={{ color: 'white', textDecoration: 'none' }}>Pricing</a>
          <a href="#contact" style={{ color: 'white', textDecoration: 'none' }}>Contact</a>
        </div>
      </nav>

      {/* Hero Section */}
      <section style={{ 
        textAlign: 'center', 
        padding: '100px 20px',
        color: 'white'
      }}>
        <h1 style={{ 
          fontSize: '4rem', 
          fontWeight: 'bold',
          marginBottom: '20px',
          lineHeight: '1.2'
        }}>
          Transform Your Ideas Into Reality
        </h1>
        <p style={{ 
          fontSize: '1.5rem', 
          marginBottom: '40px',
          opacity: 0.9,
          maxWidth: '600px',
          margin: '0 auto 40px'
        }}>
          The ultimate platform for innovators, creators, and entrepreneurs 
          to build amazing products that change the world.
        </p>

        {!subscribed ? (
          <form onSubmit={handleSubscribe} style={{ 
            display: 'flex', 
            gap: '15px', 
            justifyContent: 'center',
            maxWidth: '500px',
            margin: '0 auto'
          }}>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email address"
              required
              style={{
                flex: 1,
                padding: '18px 24px',
                border: 'none',
                borderRadius: '12px',
                fontSize: '16px',
                outline: 'none'
              }}
            />
            <button
              type="submit"
              style={{
                background: '#ff6b6b',
                color: 'white',
                border: 'none',
                padding: '18px 32px',
                borderRadius: '12px',
                cursor: 'pointer',
                fontSize: '16px',
                fontWeight: 'bold',
                whiteSpace: 'nowrap'
              }}
            >
              Get Started Free
            </button>
          </form>
        ) : (
          <div style={{ 
            background: 'rgba(255,255,255,0.2)', 
            padding: '24px', 
            borderRadius: '12px',
            display: 'inline-block',
            backdropFilter: 'blur(10px)'
          }}>
            <div style={{ fontSize: '48px', marginBottom: '16px' }}>🎉</div>
            <h3 style={{ margin: '0 0 8px 0' }}>Welcome aboard!</h3>
            <p style={{ margin: 0, opacity: 0.9 }}>
              Check your email for next steps
            </p>
          </div>
        )}
      </section>

      {/* Features Section */}
      <section id="features" style={{ 
        padding: '100px 40px',
        background: 'rgba(255,255,255,0.1)',
        backdropFilter: 'blur(10px)'
      }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <h2 style={{ 
            textAlign: 'center', 
            color: 'white', 
            fontSize: '3rem',
            marginBottom: '60px',
            fontWeight: 'bold'
          }}>
            Why Choose Us?
          </h2>
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
            gap: '40px'
          }}>
            <div style={{ 
              textAlign: 'center', 
              color: 'white',
              background: 'rgba(255,255,255,0.1)',
              padding: '40px',
              borderRadius: '20px',
              backdropFilter: 'blur(10px)'
            }}>
              <div style={{ fontSize: '4rem', marginBottom: '20px' }}>⚡</div>
              <h3 style={{ fontSize: '1.5rem', marginBottom: '15px' }}>Lightning Fast</h3>
              <p style={{ opacity: 0.9, lineHeight: '1.6' }}>
                Built for speed and performance with cutting-edge technology
              </p>
            </div>
            <div style={{ 
              textAlign: 'center', 
              color: 'white',
              background: 'rgba(255,255,255,0.1)',
              padding: '40px',
              borderRadius: '20px',
              backdropFilter: 'blur(10px)'
            }}>
              <div style={{ fontSize: '4rem', marginBottom: '20px' }}>🔒</div>
              <h3 style={{ fontSize: '1.5rem', marginBottom: '15px' }}>Secure & Reliable</h3>
              <p style={{ opacity: 0.9, lineHeight: '1.6' }}>
                Enterprise-grade security with 99.9% uptime guarantee
              </p>
            </div>
            <div style={{ 
              textAlign: 'center', 
              color: 'white',
              background: 'rgba(255,255,255,0.1)',
              padding: '40px',
              borderRadius: '20px',
              backdropFilter: 'blur(10px)'
            }}>
              <div style={{ fontSize: '4rem', marginBottom: '20px' }}>🎨</div>
              <h3 style={{ fontSize: '1.5rem', marginBottom: '15px' }}>Beautiful Design</h3>
              <p style={{ opacity: 0.9, lineHeight: '1.6' }}>
                Stunning interfaces that convert visitors into customers
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section style={{ 
        padding: '100px 40px',
        textAlign: 'center',
        color: 'white'
      }}>
        <h2 style={{ 
          fontSize: '2.5rem', 
          marginBottom: '20px',
          fontWeight: 'bold'
        }}>
          Ready to Get Started?
        </h2>
        <p style={{ 
          fontSize: '1.2rem', 
          marginBottom: '40px',
          opacity: 0.9
        }}>
          Join thousands of satisfied customers today
        </p>
        <button
          style={{
            background: '#28a745',
            color: 'white',
            border: 'none',
            padding: '20px 40px',
            borderRadius: '12px',
            cursor: 'pointer',
            fontSize: '18px',
            fontWeight: 'bold'
          }}
        >
          Start Your Free Trial
        </button>
      </section>
    </div>
  )
}`
}

function generateLandingPagePreview(prompt: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
    <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
    <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
    <div id="root"></div>
    <script type="text/babel">
        const { useState } = React;

        function LandingPage() {
            const [email, setEmail] = useState('');
            const [subscribed, setSubscribed] = useState(false);

            const handleSubscribe = (e) => {
                e.preventDefault();
                if (email.trim()) {
                    setSubscribed(true);
                }
            };

            return (
                <div style={{ 
                    minHeight: '100vh', 
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    fontFamily: 'system-ui, -apple-system, sans-serif'
                }}>
                    <nav style={{ 
                        padding: '20px 40px', 
                        display: 'flex', 
                        justifyContent: 'space-between', 
                        alignItems: 'center',
                        background: 'rgba(255,255,255,0.1)',
                        backdropFilter: 'blur(10px)'
                    }}>
                        <div style={{ 
                            fontSize: '24px', 
                            fontWeight: 'bold', 
                            color: 'white' 
                        }}>
                            🚀 ${prompt.includes("startup") ? "StartupName" : "YourBrand"}
                        </div>
                        <div style={{ display: 'flex', gap: '30px' }}>
                            <a href="#features" style={{ color: 'white', textDecoration: 'none' }}>Features</a>
                            <a href="#pricing" style={{ color: 'white', textDecoration: 'none' }}>Pricing</a>
                            <a href="#contact" style={{ color: 'white', textDecoration: 'none' }}>Contact</a>
                        </div>
                    </nav>

                    <section style={{ 
                        textAlign: 'center', 
                        padding: '100px 20px',
                        color: 'white'
                    }}>
                        <h1 style={{ 
                            fontSize: '4rem', 
                            fontWeight: 'bold',
                            marginBottom: '20px',
                            lineHeight: '1.2'
                        }}>
                            Transform Your Ideas Into Reality
                        </h1>
                        <p style={{ 
                            fontSize: '1.5rem', 
                            marginBottom: '40px',
                            opacity: 0.9,
                            maxWidth: '600px',
                            margin: '0 auto 40px'
                        }}>
                            The ultimate platform for innovators, creators, and entrepreneurs 
                            to build amazing products that change the world.
                        </p>

                        {!subscribed ? (
                            <form onSubmit={handleSubscribe} style={{ 
                                display: 'flex', 
                                gap: '15px', 
                                justifyContent: 'center',
                                maxWidth: '500px',
                                margin: '0 auto'
                            }}>
                                <input
                                    type="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    placeholder="Enter your email address"
                                    required
                                    style={{
                                        flex: 1,
                                        padding: '18px 24px',
                                        border: 'none',
                                        borderRadius: '12px',
                                        fontSize: '16px',
                                        outline: 'none'
                                    }}
                                />
                                <button
                                    type="submit"
                                    style={{
                                        background: '#ff6b6b',
                                        color: 'white',
                                        border: 'none',
                                        padding: '18px 32px',
                                        borderRadius: '12px',
                                        cursor: 'pointer',
                                        fontSize: '16px',
                                        fontWeight: 'bold',
                                        whiteSpace: 'nowrap'
                                    }}
                                >
                                    Get Started Free
                                </button>
                            </form>
                        ) : (
                            <div style={{ 
                                background: 'rgba(255,255,255,0.2)', 
                                padding: '24px', 
                                borderRadius: '12px',
                                display: 'inline-block',
                                backdropFilter: 'blur(10px)'
                            }}>
                                <div style={{ fontSize: '48px', marginBottom: '16px' }}>🎉</div>
                                <h3 style={{ margin: '0 0 8px 0' }}>Welcome aboard!</h3>
                                <p style={{ margin: 0, opacity: 0.9 }}>
                                    Check your email for next steps
                                </p>
                            </div>
                        )}
                    </section>

                    <section style={{ 
                        padding: '100px 40px',
                        background: 'rgba(255,255,255,0.1)',
                        backdropFilter: 'blur(10px)'
                    }}>
                        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
                            <h2 style={{ 
                                textAlign: 'center', 
                                color: 'white', 
                                fontSize: '3rem',
                                marginBottom: '60px',
                                fontWeight: 'bold'
                            }}>
                                Why Choose Us?
                            </h2>
                            <div style={{ 
                                display: 'grid', 
                                gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
                                gap: '40px'
                            }}>
                                <div style={{ 
                                    textAlign: 'center', 
                                    color: 'white',
                                    background: 'rgba(255,255,255,0.1)',
                                    padding: '40px',
                                    borderRadius: '20px',
                                    backdropFilter: 'blur(10px)'
                                }}>
                                    <div style={{ fontSize: '4rem', marginBottom: '20px' }}>⚡</div>
                                    <h3 style={{ fontSize: '1.5rem', marginBottom: '15px' }}>Lightning Fast</h3>
                                    <p style={{ opacity: 0.9, lineHeight: '1.6' }}>
                                        Built for speed and performance with cutting-edge technology
                                    </p>
                                </div>
                                <div style={{ 
                                    textAlign: 'center', 
                                    color: 'white',
                                    background: 'rgba(255,255,255,0.1)',
                                    padding: '40px',
                                    borderRadius: '20px',
                                    backdropFilter: 'blur(10px)'
                                }}>
                                    <div style={{ fontSize: '4rem', marginBottom: '20px' }}>🔒</div>
                                    <h3 style={{ fontSize: '1.5rem', marginBottom: '15px' }}>Secure & Reliable</h3>
                                    <p style={{ opacity: 0.9, lineHeight: '1.6' }}>
                                        Enterprise-grade security with 99.9% uptime guarantee
                                    </p>
                                </div>
                                <div style={{ 
                                    textAlign: 'center', 
                                    color: 'white',
                                    background: 'rgba(255,255,255,0.1)',
                                    padding: '40px',
                                    borderRadius: '20px',
                                    backdropFilter: 'blur(10px)'
                                }}>
                                    <div style={{ fontSize: '4rem', marginBottom: '20px' }}>🎨</div>
                                    <h3 style={{ fontSize: '1.5rem', marginBottom: '15px' }}>Beautiful Design</h3>
                                    <p style={{ opacity: 0.9, lineHeight: '1.6' }}>
                                        Stunning interfaces that convert visitors into customers
                                    </p>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            );
        }

        ReactDOM.render(<LandingPage />, document.getElementById('root'));
    </script>
</body>
</html>`
}

function generateTodoAppCode(): string {
  return `'use client'
import { useState } from 'react'

interface Task {
  id: number
  text: string
  completed: boolean
  priority: 'low' | 'medium' | 'high'
}

export default function TodoApp() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [newTask, setNewTask] = useState('')
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium')
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all')

  const addTask = (e: React.FormEvent) => {
    e.preventDefault()
    if (newTask.trim()) {
      const task: Task = {
        id: Date.now(),
        text: newTask.trim(),
        completed: false,
        priority
      }
      setTasks([task, ...tasks])
      setNewTask('')
    }
  }

  const toggleTask = (id: number) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ))
  }

  const deleteTask = (id: number) => {
    setTasks(tasks.filter(task => task.id !== id))
  }

  const clearCompleted = () => {
    setTasks(tasks.filter(task => !task.completed))
  }

  const filteredTasks = tasks.filter(task => {
    if (filter === 'active') return !task.completed
    if (filter === 'completed') return task.completed
    return true
  })

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return '#ff6b6b'
      case 'medium': return '#feca57'
      case 'low': return '#48dbfb'
      default: return '#ddd'
    }
  }

  const completedCount = tasks.filter(t => t.completed).length
  const activeCount = tasks.filter(t => !t.completed).length

  return (
    <div style={{ 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #74b9ff 0%, #0984e3 100%)',
      padding: '40px 20px',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    }}>
      <div style={{
        maxWidth: '800px',
        margin: '0 auto',
        background: 'white',
        borderRadius: '20px',
        padding: '40px',
        boxShadow: '0 20px 40px rgba(0,0,0,0.1)'
      }}>
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <h1 style={{ 
            fontSize: '3rem',
            fontWeight: 'bold',
            color: '#2d3436',
            marginBottom: '10px'
          }}>
            📝 Todo App
          </h1>
          <p style={{ color: '#636e72', fontSize: '1.1rem' }}>
            Stay organized and productive
          </p>
        </div>

        {/* Add Task Form */}
        <form onSubmit={addTask} style={{ 
          display: 'flex', 
          gap: '12px',
          marginBottom: '30px',
          flexWrap: 'wrap'
        }}>
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            placeholder="Add a new task..."
            style={{
              flex: 1,
              minWidth: '300px',
              padding: '16px',
              border: '2px solid #ddd',
              borderRadius: '12px',
              fontSize: '16px',
              outline: 'none'
            }}
          />
          <select
            value={priority}
            onChange={(e) => setPriority(e.target.value as 'low' | 'medium' | 'high')}
            style={{
              padding: '16px',
              border: '2px solid #ddd',
              borderRadius: '12px',
              fontSize: '16px',
              outline: 'none',
              background: 'white'
            }}
          >
            <option value="low">Low Priority</option>
            <option value="medium">Medium Priority</option>
            <option value="high">High Priority</option>
          </select>
          <button
            type="submit"
            style={{
              background: '#00b894',
              color: 'white',
              border: 'none',
              padding: '16px 24px',
              borderRadius: '12px',
              cursor: 'pointer',
              fontSize: '16px',
              fontWeight: 'bold',
              whiteSpace: 'nowrap'
            }}
          >
            Add Task
          </button>
        </form>

        {/* Stats */}
        <div style={{ 
          display: 'flex', 
          gap: '20px', 
          marginBottom: '30px',
          flexWrap: 'wrap'
        }}>
          <div style={{ 
            background: '#f8f9fa', 
            padding: '16px 24px', 
            borderRadius: '12px',
            textAlign: 'center',
            flex: 1,
            minWidth: '120px'
          }}>
            <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#0984e3' }}>
              {tasks.length}
            </div>
            <div style={{ color: '#636e72', fontSize: '14px' }}>Total</div>
          </div>
          <div style={{ 
            background: '#f8f9fa', 
            padding: '16px 24px', 
            borderRadius: '12px',
            textAlign: 'center',
            flex: 1,
            minWidth: '120px'
          }}>
            <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#00b894' }}>
              {activeCount}
            </div>
            <div style={{ color: '#636e72', fontSize: '14px' }}>Active</div>
          </div>
          <div style={{ 
            background: '#f8f9fa', 
            padding: '16px 24px', 
            borderRadius: '12px',
            textAlign: 'center',
            flex: 1,
            minWidth: '120px'
          }}>
            <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#636e72' }}>
              {completedCount}
            </div>
            <div style={{ color: '#636e72', fontSize: '14px' }}>Completed</div>
          </div>
        </div>

        {/* Filters */}
        <div style={{ 
          display: 'flex', 
          gap: '10px', 
          marginBottom: '30px',
          justifyContent: 'center',
          flexWrap: 'wrap'
        }}>
          {(['all', 'active', 'completed'] as const).map(filterType => (
            <button
              key={filterType}
              onClick={() => setFilter(filterType)}
              style={{
                background: filter === filterType ? '#0984e3' : '#f8f9fa',
                color: filter === filterType ? 'white' : '#636e72',
                border: 'none',
                padding: '10px 20px',
                borderRadius: '20px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '500',
                textTransform: 'capitalize'
              }}
            >
              {filterType}
            </button>
          ))}
          {completedCount > 0 && (
            <button
              onClick={clearCompleted}
              style={{
                background: '#ff6b6b',
                color: 'white',
                border: 'none',
                padding: '10px 20px',
                borderRadius: '20px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '500'
              }}
            >
              Clear Completed
            </button>
          )}
        </div>

        {/* Tasks List */}
        <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
          {filteredTasks.length === 0 ? (
            <div style={{ 
              textAlign: 'center', 
              color: '#636e72',
              fontSize: '18px',
              padding: '60px 20px'
            }}>
              {tasks.length === 0 ? (
                <>
                  <div style={{ fontSize: '4rem', marginBottom: '20px' }}>📝</div>
                  <p>No tasks yet. Add one above!</p>
                </>
              ) : (
                <>
                  <div style={{ fontSize: '4rem', marginBottom: '20px' }}>🔍</div>
                  <p>No {filter} tasks found</p>
                </>
              )}
            </div>
          ) : (
            filteredTasks.map(task => (
              <div
                key={task.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '16px',
                  padding: '20px',
                  background: task.completed ? '#f8f9fa' : 'white',
                  border: \`2px solid \${task.completed ? '#00b894' : '#e9ecef'}\`,
                  borderRadius: '12px',
                  marginBottom: '12px',
                  transition: 'all 0.2s ease'
                }}
              >
                <div
                  style={{
                    width: '6px',
                    height: '40px',
                    background: getPriorityColor(task.priority),
                    borderRadius: '3px'
                  }}
                />
                <input
                  type="checkbox"
                  checked={task.completed}
                  onChange={() => toggleTask(task.id)}
                  style={{ 
                    transform: 'scale(1.5)',
                    cursor: 'pointer'
                  }}
                />
                <span
                  style={{
                    flex: 1,
                    textDecoration: task.completed ? 'line-through' : 'none',
                    color: task.completed ? '#636e72' : '#2d3436',
                    fontSize: '16px',
                    lineHeight: '1.5'
                  }}
                >
                  {task.text}
                </span>
                <span
                  style={{
                    background: getPriorityColor(task.priority),
                    color: 'white',
                    padding: '4px 12px',
                    borderRadius: '12px',
                    fontSize: '12px',
                    fontWeight: 'bold',
                    textTransform: 'uppercase'
                  }}
                >
                  {task.priority}
                </span>
                <button
                  onClick={() => deleteTask(task.id)}
                  style={{
                    background: '#ff6b6b',
                    color: 'white',
                    border: 'none',
                    padding: '8px 12px',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    fontSize: '14px'
                  }}
                >
                  🗑️
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}`
}

function generateTodoAppPreview(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todo App</title>
    <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
    <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
    <div id="root"></div>
    <script type="text/babel">
        const { useState } = React;

        function TodoApp() {
            const [tasks, setTasks] = useState([]);
            const [newTask, setNewTask] = useState('');
            const [priority, setPriority] = useState('medium');
            const [filter, setFilter] = useState('all');

            const addTask = (e) => {
                e.preventDefault();
                if (newTask.trim()) {
                    const task = {
                        id: Date.now(),
                        text: newTask.trim(),
                        completed: false,
                        priority
                    };
                    setTasks([task, ...tasks]);
                    setNewTask('');
                }
            };

            const toggleTask = (id) => {
                setTasks(tasks.map(task => 
                    task.id === id ? { ...task, completed: !task.completed } : task
                ));
            };

            const deleteTask = (id) => {
                setTasks(tasks.filter(task => task.id !== id));
            };

            const clearCompleted = () => {
                setTasks(tasks.filter(task => !task.completed));
            };

            const filteredTasks = tasks.filter(task => {
                if (filter === 'active') return !task.completed;
                if (filter === 'completed') return task.completed;
                return true;
            });

            const getPriorityColor = (priority) => {
                switch (priority) {
                    case 'high': return '#ff6b6b';
                    case 'medium': return '#feca57';
                    case 'low': return '#48dbfb';
                    default: return '#ddd';
                }
            };

            const completedCount = tasks.filter(t => t.completed).length;
            const activeCount = tasks.filter(t => !t.completed).length;

            return (
                <div style={{ 
                    minHeight: '100vh', 
                    background: 'linear-gradient(135deg, #74b9ff 0%, #0984e3 100%)',
                    padding: '40px 20px',
                    fontFamily: 'system-ui, -apple-system, sans-serif'
                }}>
                    <div style={{
                        maxWidth: '800px',
                        margin: '0 auto',
                        background: 'white',
                        borderRadius: '20px',
                        padding: '40px',
                        boxShadow: '0 20px 40px rgba(0,0,0,0.1)'
                    }}>
                        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
                            <h1 style={{ 
                                fontSize: '3rem',
                                fontWeight: 'bold',
                                color: '#2d3436',
                                marginBottom: '10px'
                            }}>
                                📝 Todo App
                            </h1>
                            <p style={{ color: '#636e72', fontSize: '1.1rem' }}>
                                Stay organized and productive
                            </p>
                        </div>

                        <form onSubmit={addTask} style={{ 
                            display: 'flex', 
                            gap: '12px',
                            marginBottom: '30px',
                            flexWrap: 'wrap'
                        }}>
                            <input
                                type="text"
                                value={newTask}
                                onChange={(e) => setNewTask(e.target.value)}
                                placeholder="Add a new task..."
                                style={{
                                    flex: 1,
                                    minWidth: '300px',
                                    padding: '16px',
                                    border: '2px solid #ddd',
                                    borderRadius: '12px',
                                    fontSize: '16px',
                                    outline: 'none'
                                }}
                            />
                            <select
                                value={priority}
                                onChange={(e) => setPriority(e.target.value)}
                                style={{
                                    padding: '16px',
                                    border: '2px solid #ddd',
                                    borderRadius: '12px',
                                    fontSize: '16px',
                                    outline: 'none',
                                    background: 'white'
                                }}
                            >
                                <option value="low">Low Priority</option>
                                <option value="medium">Medium Priority</option>
                                <option value="high">High Priority</option>
                            </select>
                            <button
                                type="submit"
                                style={{
                                    background: '#00b894',
                                    color: 'white',
                                    border: 'none',
                                    padding: '16px 24px',
                                    borderRadius: '12px',
                                    cursor: 'pointer',
                                    fontSize: '16px',
                                    fontWeight: 'bold',
                                    whiteSpace: 'nowrap'
                                }}
                            >
                                Add Task
                            </button>
                        </form>

                        <div style={{ 
                            display: 'flex', 
                            gap: '20px', 
                            marginBottom: '30px',
                            flexWrap: 'wrap'
                        }}>
                            <div style={{ 
                                background: '#f8f9fa', 
                                padding: '16px 24px', 
                                borderRadius: '12px',
                                textAlign: 'center',
                                flex: 1,
                                minWidth: '120px'
                            }}>
                                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#0984e3' }}>
                                    {tasks.length}
                                </div>
                                <div style={{ color: '#636e72', fontSize: '14px' }}>Total</div>
                            </div>
                            <div style={{ 
                                background: '#f8f9fa', 
                                padding: '16px 24px', 
                                borderRadius: '12px',
                                textAlign: 'center',
                                flex: 1,
                                minWidth: '120px'
                            }}>
                                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#00b894' }}>
                                    {activeCount}
                                </div>
                                <div style={{ color: '#636e72', fontSize: '14px' }}>Active</div>
                            </div>
                            <div style={{ 
                                background: '#f8f9fa', 
                                padding: '16px 24px', 
                                borderRadius: '12px',
                                textAlign: 'center',
                                flex: 1,
                                minWidth: '120px'
                            }}>
                                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#636e72' }}>
                                    {completedCount}
                                </div>
                                <div style={{ color: '#636e72', fontSize: '14px' }}>Completed</div>
                            </div>
                        </div>

                        <div style={{ 
                            display: 'flex', 
                            gap: '10px', 
                            marginBottom: '30px',
                            justifyContent: 'center',
                            flexWrap: 'wrap'
                        }}>
                            {['all', 'active', 'completed'].map(filterType => (
                                <button
                                    key={filterType}
                                    onClick={() => setFilter(filterType)}
                                    style={{
                                        background: filter === filterType ? '#0984e3' : '#f8f9fa',
                                        color: filter === filterType ? 'white' : '#636e72',
                                        border: 'none',
                                        padding: '10px 20px',
                                        borderRadius: '20px',
                                        cursor: 'pointer',
                                        fontSize: '14px',
                                        fontWeight: '500',
                                        textTransform: 'capitalize'
                                    }}
                                >
                                    {filterType}
                                </button>
                            ))}
                            {completedCount > 0 && (
                                <button
                                    onClick={clearCompleted}
                                    style={{
                                        background: '#ff6b6b',
                                        color: 'white',
                                        border: 'none',
                                        padding: '10px 20px',
                                        borderRadius: '20px',
                                        cursor: 'pointer',
                                        fontSize: '14px',
                                        fontWeight: '500'
                                    }}
                                >
                                    Clear Completed
                                </button>
                            )}
                        </div>

                        <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
                            {filteredTasks.length === 0 ? (
                                <div style={{ 
                                    textAlign: 'center', 
                                    color: '#636e72',
                                    fontSize: '18px',
                                    padding: '60px 20px'
                                }}>
                                    {tasks.length === 0 ? (
                                        <>
                                            <div style={{ fontSize: '4rem', marginBottom: '20px' }}>📝</div>
                                            <p>No tasks yet. Add one above!</p>
                                        </>
                                    ) : (
                                        <>
                                            <div style={{ fontSize: '4rem', marginBottom: '20px' }}>🔍</div>
                                            <p>No {filter} tasks found</p>
                                        </>
                                    )}
                                </div>
                            ) : (
                                filteredTasks.map(task => (
                                    <div
                                        key={task.id}
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '16px',
                                            padding: '20px',
                                            background: task.completed ? '#f8f9fa' : 'white',
                                            border: \`2px solid \${task.completed ? '#00b894' : '#e9ecef'}\`,
                                            borderRadius: '12px',
                                            marginBottom: '12px',
                                            transition: 'all 0.2s ease'
                                        }}
                                    >
                                        <div
                                            style={{
                                                width: '6px',
                                                height: '40px',
                                                background: getPriorityColor(task.priority),
                                                borderRadius: '3px'
                                            }}
                                        />
                                        <input
                                            type="checkbox"
                                            checked={task.completed}
                                            onChange={() => toggleTask(task.id)}
                                            style={{ 
                                                transform: 'scale(1.5)',
                                                cursor: 'pointer'
                                            }}
                                        />
                                        <span
                                            style={{
                                                flex: 1,
                                                textDecoration: task.completed ? 'line-through' : 'none',
                                                color: task.completed ? '#636e72' : '#2d3436',
                                                fontSize: '16px',
                                                lineHeight: '1.5'
                                            }}
                                        >
                                            {task.text}
                                        </span>
                                        <span
                                            style={{
                                                background: getPriorityColor(task.priority),
                                                color: 'white',
                                                padding: '4px 12px',
                                                borderRadius: '12px',
                                                fontSize: '12px',
                                                fontWeight: 'bold',
                                                textTransform: 'uppercase'
                                            }}
                                        >
                                            {task.priority}
                                        </span>
                                        <button
                                            onClick={() => deleteTask(task.id)}
                                            style={{
                                                background: '#ff6b6b',
                                                color: 'white',
                                                border: 'none',
                                                padding: '8px 12px',
                                                borderRadius: '8px',
                                                cursor: 'pointer',
                                                fontSize: '14px'
                                            }}
                                        >
                                            🗑️
                                        </button>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            );
        }

        ReactDOM.render(<TodoApp />, document.getElementById('root'));
    </script>
</body>
</html>`
}

function generateCalculatorCode(): string {
  return `'use client'
import { useState } from 'react'

export default function Calculator() {
  const [display, setDisplay] = useState('0')
  const [previousValue, setPreviousValue] = useState<number | null>(null)
  const [operation, setOperation] = useState<string | null>(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)

  const inputNumber = (num: string) => {
    if (waitingForOperand) {
      setDisplay(num)
      setWaitingForOperand(false)
    } else {
      setDisplay(display === '0' ? num : display + num)
    }
  }

  const inputDecimal = () => {
    if (waitingForOperand) {
      setDisplay('0.')
      setWaitingForOperand(false)
    } else if (display.indexOf('.') === -1) {
      setDisplay(display + '.')
    }
  }

  const inputOperation = (nextOperation: string) => {
    const inputValue = parseFloat(display)

    if (previousValue === null) {
      setPreviousValue(inputValue)
    } else if (operation) {
      const currentValue = previousValue || 0
      const newValue = calculate(currentValue, inputValue, operation)

      setDisplay(String(newValue))
      setPreviousValue(newValue)
    }

    setWaitingForOperand(true)
    setOperation(nextOperation)
  }

  const calculate = (firstValue: number, secondValue: number, operation: string): number => {
    switch (operation) {
      case '+': return firstValue + secondValue
      case '-': return firstValue - secondValue
      case '×': return firstValue * secondValue
      case '÷': return firstValue / secondValue
      case '=': return secondValue
      default: return secondValue
    }
  }

  const performCalculation = () => {
    const inputValue = parseFloat(display)

    if (previousValue !== null && operation) {
      const newValue = calculate(previousValue, inputValue, operation)
      setDisplay(String(newValue))
      setPreviousValue(null)
      setOperation(null)
      setWaitingForOperand(true)
    }
  }

  const clear = () => {
    setDisplay('0')
    setPreviousValue(null)
    setOperation(null)
    setWaitingForOperand(false)
  }

  const clearEntry = () => {
    setDisplay('0')
  }

  const backspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1))
    } else {
      setDisplay('0')
    }
  }

  const Button = ({ onClick, className = '', children, style = {}, ...props }: any) => (
    <button
      onClick={onClick}
      style={{
        padding: '20px',
        fontSize: '20px',
        border: 'none',
        borderRadius: '12px',
        cursor: 'pointer',
        fontWeight: 'bold',
        transition: 'all 0.2s ease',
        ...style
      }}
      {...props}
    >
      {children}
    </button>
  )

  return (
    <div style={{ 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #2d3436 0%, #636e72 100%)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    }}>
      <div style={{
        background: '#2d3436',
        borderRadius: '24px',
        padding: '30px',
        boxShadow: '0 20px 40px rgba(0,0,0,0.3)',
        maxWidth: '400px',
        width: '100%'
      }}>
        <div style={{
          background: '#000',
          color: '#fff',
          padding: '30px 20px',
          borderRadius: '16px',
          marginBottom: '24px',
          textAlign: 'right',
          fontSize: '2.5rem',
          fontWeight: 'bold',
          minHeight: '80px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-end',
          wordBreak: 'break-all',
          fontFamily: 'monospace'
        }}>
          {display}
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: '12px'
        }}>
          {/* Row 1 */}
          <Button
            onClick={clear}
            style={{ 
              background: '#e17055', 
              color: 'white',
              gridColumn: 'span 2'
            }}
          >
            Clear
          </Button>
          <Button
            onClick={backspace}
            style={{ background: '#fdcb6e', color: '#2d3436' }}
          >
            ⌫
          </Button>
          <Button
            onClick={() => inputOperation('÷')}
            style={{ background: '#fdcb6e', color: '#2d3436' }}
          >
            ÷
          </Button>

          {/* Row 2 */}
          <Button
            onClick={() => inputNumber('7')}
            style={{ background: '#74b9ff', color: 'white' }}
          >
            7
          </Button>
          <Button
            onClick={() => inputNumber('8')}
            style={{ background: '#74b9ff', color: 'white' }}
          >
            8
          </Button>
          <Button
            onClick={() => inputNumber('9')}
            style={{ background: '#74b9ff', color: 'white' }}
          >
            9
          </Button>
          <Button
            onClick={() => inputOperation('×')}
            style={{ background: '#fdcb6e', color: '#2d3436' }}
          >
            ×
          </Button>

          {/* Row 3 */}
          <Button
            onClick={() => inputNumber('4')}
            style={{ background: '#74b9ff', color: 'white' }}
          >
            4
          </Button>
          <Button
            onClick={() => inputNumber('5')}
            style={{ background: '#74b9ff', color: 'white' }}
          >
            5
          </Button>
          <Button
            onClick={() => inputNumber('6')}
            style={{ background: '#74b9ff', color: 'white' }}
          >
            6
          </Button>
          <Button
            onClick={() => inputOperation('-')}
            style={{ background: '#fdcb6e', color: '#2d3436' }}
          >
            -
          </Button>

          {/* Row 4 */}
          <Button
            onClick={() => inputNumber('1')}
            style={{ background: '#74b9ff', color: 'white' }}
          >
            1
          </Button>
          <Button
            onClick={() => inputNumber('2')}
            style={{ background: '#74b9ff', color: 'white' }}
          >
            2
          </Button>
          <Button
            onClick={() => inputNumber('3')}
            style={{ background: '#74b9ff', color: 'white' }}
          >
            3
          </Button>
          <Button
            onClick={() => inputOperation('+')}
            style={{ background: '#fdcb6e', color: '#2d3436' }}
          >
            +
          </Button>

          {/* Row 5 */}
          <Button
            onClick={() => inputNumber('0')}
            style={{ 
              background: '#74b9ff', 
              color: 'white',
              gridColumn: 'span 2'
            }}
          >
            0
          </Button>
          <Button
            onClick={inputDecimal}
            style={{ background: '#74b9ff', color: 'white' }}
          >
            .
          </Button>
          <Button
            onClick={performCalculation}
            style={{ 
              background: '#00b894', 
              color: 'white'
            }}
          >
            =
          </Button>
        </div>
      </div>
    </div>
  )
}`
}

function generateCalculatorPreview(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator</title>
    <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
    <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
    <div id="root"></div>
    <script type="text/babel">
        const { useState } = React;

        function Calculator() {
            const [display, setDisplay] = useState('0');
            const [previousValue, setPreviousValue] = useState(null);
            const [operation, setOperation] = useState(null);
            const [waitingForOperand, setWaitingForOperand] = useState(false);

            const inputNumber = (num) => {
                if (waitingForOperand) {
                    setDisplay(num);
                    setWaitingForOperand(false);
                } else {
                    setDisplay(display === '0' ? num : display + num);
                }
            };

            const inputDecimal = () => {
                if (waitingForOperand) {
                    setDisplay('0.');
                    setWaitingForOperand(false);
                } else if (display.indexOf('.') === -1) {
                    setDisplay(display + '.');
                }
            };

            const inputOperation = (nextOperation) => {
                const inputValue = parseFloat(display);

                if (previousValue === null) {
                    setPreviousValue(inputValue);
                } else if (operation) {
                    const currentValue = previousValue || 0;
                    const newValue = calculate(currentValue, inputValue, operation);

                    setDisplay(String(newValue));
                    setPreviousValue(newValue);
                }

                setWaitingForOperand(true);
                setOperation(nextOperation);
            };

            const calculate = (firstValue, secondValue, operation) => {
                switch (operation) {
                    case '+': return firstValue + secondValue;
                    case '-': return firstValue - secondValue;
                    case '×': return firstValue * secondValue;
                    case '÷': return firstValue / secondValue;
                    case '=': return secondValue;
                    default: return secondValue;
                }
            };

            const performCalculation = () => {
                const inputValue = parseFloat(display);

                if (previousValue !== null && operation) {
                    const newValue = calculate(previousValue, inputValue, operation);
                    setDisplay(String(newValue));
                    setPreviousValue(null);
                    setOperation(null);
                    setWaitingForOperand(true);
                }
            };

            const clear = () => {
                setDisplay('0');
                setPreviousValue(null);
                setOperation(null);
                setWaitingForOperand(false);
            };

            const backspace = () => {
                if (display.length > 1) {
                    setDisplay(display.slice(0, -1));
                } else {
                    setDisplay('0');
                }
            };

            const Button = ({ onClick, style = {}, children }) => (
                React.createElement('button', {
                    onClick,
                    style: {
                        padding: '20px',
                        fontSize: '20px',
                        border: 'none',
                        borderRadius: '12px',
                        cursor: 'pointer',
                        fontWeight: 'bold',
                        transition: 'all 0.2s ease',
                        ...style
                    }
                }, children)
            );

            return (
                <div style={{ 
                    minHeight: '100vh', 
                    background: 'linear-gradient(135deg, #2d3436 0%, #636e72 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: '20px',
                    fontFamily: 'system-ui, -apple-system, sans-serif'
                }}>
                    <div style={{
                        background: '#2d3436',
                        borderRadius: '24px',
                        padding: '30px',
                        boxShadow: '0 20px 40px rgba(0,0,0,0.3)',
                        maxWidth: '400px',
                        width: '100%'
                    }}>
                        <div style={{
                            background: '#000',
                            color: '#fff',
                            padding: '30px 20px',
                            borderRadius: '16px',
                            marginBottom: '24px',
                            textAlign: 'right',
                            fontSize: '2.5rem',
                            fontWeight: 'bold',
                            minHeight: '80px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'flex-end',
                            wordBreak: 'break-all',
                            fontFamily: 'monospace'
                        }}>
                            {display}
                        </div>

                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(4, 1fr)',
                            gap: '12px'
                        }}>
                            <Button
                                onClick={clear}
                                style={{ 
                                    background: '#e17055', 
                                    color: 'white',
                                    gridColumn: 'span 2'
                                }}
                            >
                                Clear
                            </Button>
                            <Button
                                onClick={backspace}
                                style={{ background: '#fdcb6e', color: '#2d3436' }}
                            >
                                ⌫
                            </Button>
                            <Button
                                onClick={() => inputOperation('÷')}
                                style={{ background: '#fdcb6e', color: '#2d3436' }}
                            >
                                ÷
                            </Button>

                            <Button
                                onClick={() => inputNumber('7')}
                                style={{ background: '#74b9ff', color: 'white' }}
                            >
                                7
                            </Button>
                            <Button
                                onClick={() => inputNumber('8')}
                                style={{ background: '#74b9ff', color: 'white' }}
                            >
                                8
                            </Button>
                            <Button
                                onClick={() => inputNumber('9')}
                                style={{ background: '#74b9ff', color: 'white' }}
                            >
                                9
                            </Button>
                            <Button
                                onClick={() => inputOperation('×')}
                                style={{ background: '#fdcb6e', color: '#2d3436' }}
                            >
                                ×
                            </Button>

                            <Button
                                onClick={() => inputNumber('4')}
                                style={{ background: '#74b9ff', color: 'white' }}
                            >
                                4
                            </Button>
                            <Button
                                onClick={() => inputNumber('5')}
                                style={{ background: '#74b9ff', color: 'white' }}
                            >
                                5
                            </Button>
                            <Button
                                onClick={() => inputNumber('6')}
                                style={{ background: '#74b9ff', color: 'white' }}
                            >
                                6
                            </Button>
                            <Button
                                onClick={() => inputOperation('-')}
                                style={{ background: '#fdcb6e', color: '#2d3436' }}
                            >
                                -
                            </Button>

                            <Button
                                onClick={() => inputNumber('1')}
                                style={{ background: '#74b9ff', color: 'white' }}
                            >
                                1
                            </Button>
                            <Button
                                onClick={() => inputNumber('2')}
                                style={{ background: '#74b9ff', color: 'white' }}
                            >
                                2
                            </Button>
                            <Button
                                onClick={() => inputNumber('3')}
                                style={{ background: '#74b9ff', color: 'white' }}
                            >
                                3
                            </Button>
                            <Button
                                onClick={() => inputOperation('+')}
                                style={{ background: '#fdcb6e', color: '#2d3436' }}
                            >
                                +
                            </Button>

                            <Button
                                onClick={() => inputNumber('0')}
                                style={{ 
                                    background: '#74b9ff', 
                                    color: 'white',
                                    gridColumn: 'span 2'
                                }}
                            >
                                0
                            </Button>
                            <Button
                                onClick={inputDecimal}
                                style={{ background: '#74b9ff', color: 'white' }}
                            >
                                .
                            </Button>
                            <Button
                                onClick={performCalculation}
                                style={{ 
                                    background: '#00b894', 
                                    color: 'white'
                                }}
                            >
                                =
                            </Button>
                        </div>
                    </div>
                </div>
            );
        }

        ReactDOM.render(<Calculator />, document.getElementById('root'));
    </script>
</body>
</html>`
}

function generateWeatherAppCode(): string {
  return `'use client'
import { useState, useEffect } from 'react'

interface WeatherData {
  name: string
  main: {
    temp: number
    humidity: number
  }
  weather: {
    description: string
    icon: string
  }[]
  wind: {
    speed: number
  }
}

export default function WeatherApp() {
  const [city, setCity] = useState('London')
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const apiKey = 'YOUR_API_KEY' // Replace with your actual API key

  useEffect(() => {
    const fetchWeather = async () => {
      setLoading(true)
      setError(null)
      try {
        const response = await fetch(
          \`https://api.openweathermap.org/data/2.5/weather?q=\${city}&appid=\${apiKey}&units=metric\`
        )
        if (!response.ok) {
          throw new Error('City not found')
        }
        const data = await response.json()
        setWeather({
          name: data.name,
          main: {
            temp: data.main.temp,
            humidity: data.main.humidity
          },
          weather: data.weather.map((w: any) => ({
            description: w.description,
            icon: w.icon
          })),
          wind: {
            speed: data.wind.speed
          }
        })
      } catch (err: any) {
        setError(err.message)
        setWeather(null)
      } finally {
        setLoading(false)
      }
    }

    fetchWeather()
  }, [city, apiKey])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const input = e.target as HTMLFormElement
    const newCity = input.city.value
    setCity(newCity)
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #4CAF50 0%, #81C784 100%)',
      padding: '40px 20px',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }}>
      <div style={{
        maxWidth: '600px',
        width: '100%',
        background: 'rgba(255, 255, 255, 0.9)',
        borderRadius: '20px',
        padding: '40px',
        boxShadow: '0 20px 40px rgba(0,0,0,0.1)'
      }}>
        <h1 style={{
          fontSize: '2.5rem',
          fontWeight: 'bold',
          color: '#2E7D32',
          marginBottom: '20px',
          textAlign: 'center'
        }}>
          🌦️ Weather App
        </h1>

        <form onSubmit={handleSubmit} style={{
          marginBottom: '30px',
          display: 'flex',
          gap: '10px'
        }}>
          <input
            type="text"
            id="city"
            name="city"
            placeholder="Enter city name"
            style={{
              flex: 1,
              padding: '16px',
              border: '2px solid #A5D6A7',
              borderRadius: '12px',
              fontSize: '16px',
              outline: 'none'
            }}
          />
          <button
            type="submit"
            style={{
              background: '#43A047',
              color: 'white',
              border: 'none',
              padding: '16px 24px',
              borderRadius: '12px',
              cursor: 'pointer',
              fontSize: '16px',
              fontWeight: 'bold',
              whiteSpace: 'nowrap'
            }}
          >
            Get Weather
          </button>
        </form>

        {loading && (
          <div style={{
            textAlign: 'center',
            color: '#2E7D32',
            fontSize: '1.2rem'
          }}>
            Loading weather data...
          </div>
        )}

        {error && (
          <div style={{
            textAlign: 'center',
            color: '#D32F2F',
            fontSize: '1.2rem'
          }}>
            Error: {error}
          </div>
        )}

        {weather && (
          <div style={{
            textAlign: 'center',
            marginTop: '30px'
          }}>
            <h2 style={{
              fontSize: '2rem',
              color: '#2E7D32',
              marginBottom: '10px'
            }}>
              {weather.name}
            </h2>
            <div style={{
              fontSize: '3rem',
              fontWeight: 'bold',
              color: '#2E7D32',
              marginBottom: '10px'
            }}>
              {weather.main.temp}°C
            </div>
            <img
              src={\`https://openweathermap.org/img/wn/\${weather.weather[0].icon || "/placeholder.svg"}@2x.png\`}
              alt="Weather Icon"
              style={{ margin: '0 auto', display: 'block' }}
            />
            <div style={{
              fontSize: '1.2rem',
              color: '#2E7D32',
              marginBottom: '10px'
            }}>
              {weather.weather[0].description}
            </div>
            <div style={{
              fontSize: '1rem',
              color: '#2E7D32'
            }}>
              Humidity: {weather.main.humidity}%
            </div>
            <div style={{
              fontSize: '1rem',
              color: '#2E7D32'
            }}>
              Wind Speed: {weather.wind.speed} m/s
            </div>
          </div>
        )}
      </div>
    </div>
  )
}`
}

function generateWeatherAppPreview(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Weather App</title>
  <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
  <div id="root"></div>
  <script type="text/babel">
    const { useState, useEffect } = React;

    function WeatherApp() {
      const [city, setCity] = useState('London');
      const [weather, setWeather] = useState(null);
      const [loading, setLoading] = useState(false);
      const [error, setError] = useState(null);

      const apiKey = 'YOUR_API_KEY'; // Replace with your actual API key

      useEffect(() => {
        const fetchWeather = async () => {
          setLoading(true);
          setError(null);
          try {
            const response = await fetch(
              \`https://api.openweathermap.org/data/2.5/weather?q=\${city}&appid=\${apiKey}&units=metric\`
            );
            if (!response.ok) {
              throw new Error('City not found');
            }
            const data = await response.json();
            setWeather({
              name: data.name,
              main: {
                temp: data.main.temp,
                humidity: data.main.humidity
              },
              weather: data.weather.map((w) => ({
                description: w.description,
                icon: w.icon
              })),
              wind: {
                speed: data.wind.speed
              }
            });
          } catch (err) {
            setError(err.message);
            setWeather(null);
          } finally {
            setLoading(false);
          }
        };

        fetchWeather();
      }, [city, apiKey]);

      const handleSubmit = (e) => {
        e.preventDefault();
        const input = e.target;
        const newCity = input.city.value;
        setCity(newCity);
      };

      return (
        <div style={{
          minHeight: '100vh',
          background: 'linear-gradient(135deg, #4CAF50 0%, #81C784 100%)',
          padding: '40px 20px',
          fontFamily: 'system-ui, -apple-system, sans-serif',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          <div style={{
            maxWidth: '600px',
            width: '100%',
            background: 'rgba(255, 255, 255, 0.9)',
            borderRadius: '20px',
            padding: '40px',
            boxShadow: '0 20px 40px rgba(0,0,0,0.1)'
          }}>
            <h1 style={{
              fontSize: '2.5rem',
              fontWeight: 'bold',
              color: '#2E7D32',
              marginBottom: '20px',
              textAlign: 'center'
            }}>
              🌦️ Weather App
            </h1>

            <form onSubmit={handleSubmit} style={{
              marginBottom: '30px',
              display: 'flex',
              gap: '10px'
            }}>
              <input
                type="text"
                id="city"
                name="city"
                placeholder="Enter city name"
                style={{
                  flex: 1,
                  padding: '16px',
                  border: '2px solid #A5D6A7',
                  borderRadius: '12px',
                  fontSize: '16px',
                  outline: 'none'
                }}
              />
              <button
                type="submit"
                style={{
                  background: '#43A047',
                  color: 'white',
                  border: 'none',
                  padding: '16px 24px',
                  borderRadius: '12px',
                  cursor: 'pointer',
                  fontSize: '16px',
                  fontWeight: 'bold',
                  whiteSpace: 'nowrap'
                }}
              >
                Get Weather
              </button>
            </form>

            {loading && (
              <div style={{
                textAlign: 'center',
                color: '#2E7D32',
                fontSize: '1.2rem'
              }}>
                Loading weather data...
              </div>
            )}

            {error && (
              <div style={{
                textAlign: 'center',
                color: '#D32F2F',
                fontSize: '1.2rem'
              }}>
                Error: {error}
              </div>
            )}

            {weather && (
              <div style={{
                textAlign: 'center',
                marginTop: '30px'
              }}>
                <h2 style={{
                  fontSize: '2rem',
                  color: '#2E7D32',
                  marginBottom: '10px'
                }}>
                  {weather.name}
                </h2>
                <div style={{
                  fontSize: '3rem',
                  fontWeight: 'bold',
                  color: '#2E7D32',
                  marginBottom: '10px'
                }}>
                  {weather.main.temp}°C
                </div>
                <img
                  src={\`https://openweathermap.org/img/wn/\${weather.weather[0].icon || "/placeholder.svg"}@2x.png\`}
                  alt="Weather Icon"
                  style={{ margin: '0 auto', display: 'block' }}
                />
                <div style={{
                  fontSize: '1.2rem',
                  color: '#2E7D32',
                  marginBottom: '10px'
                }}>
                  {weather.weather[0].description}
                </div>
                <div style={{
                  fontSize: '1rem',
                  color: '#2E7D32'
                }}>
                  Humidity: {weather.main.humidity}%
                </div>
                <div style={{
                  fontSize: '1rem',
                  color: '#2E7D32'
                }}>
                  Wind Speed: {weather.wind.speed} m/s
                </div>
              </div>
            )}
          </div>
        </div>
      );
    }
    ReactDOM.render(<WeatherApp />, document.getElementById('root'));
  </script>
</body>
</html>`
}

function generateBlogCode(): string {
  return `'use client'
import { useState, useEffect } from 'react'

interface Post {
  id: number
  title: string
  content: string
  author: string
  date: string
}

export default function Blog() {
  const [posts, setPosts] = useState<Post[]>([])
  const [newPost, setNewPost] = useState({
    title: '',
    content: '',
    author: ''
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchPosts = async () => {
      setLoading(true)
      setError(null)
      try {
        // Simulate fetching posts from an API
        await new Promise(resolve => setTimeout(resolve, 1000))
        const mockPosts: Post[] = [
          {
            id: 1,
            title: 'First Post',
            content: 'This is the first post content.',
            author: 'John Doe',
            date: '2024-01-01'
          },
          {
            id: 2,
            title: 'Second Post',
            content: 'This is the second post content.',
            author: 'Jane Smith',
            date: '2024-01-05'
          }
        ]
        setPosts(mockPosts)
      } catch (err: any) {
        setError(err.message)
        setPosts([])
      } finally {
        setLoading(false)
      }
    }

    fetchPosts()
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setNewPost(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const addPost = (e: React.FormEvent) => {
    e.preventDefault()
    if (newPost.title.trim() && newPost.content.trim() && newPost.author.trim()) {
      const post: Post = {
        id: Date.now(),
        title: newPost.title.trim(),
        content: newPost.content.trim(),
        author: newPost.author.trim(),
        date: new Date().toISOString().slice(0, 10)
      }
      setPosts([post, ...posts])
      setNewPost({
        title: '',
        content: '',
        author: ''
      })
    }
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #6441A5 0%, #2A0845 100%)',
      padding: '40px 20px',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      color: 'white'
    }}>
      <div style={{
        maxWidth: '800px',
        margin: '0 auto',
        background: 'rgba(255, 255, 255, 0.1)',
        borderRadius: '20px',
        padding: '40px',
        boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
        backdropFilter: 'blur(10px)'
      }}>
        <h1 style={{
          fontSize: '3rem',
          fontWeight: 'bold',
          marginBottom: '30px',
          textAlign: 'center'
        }}>
          📝 My Blog
        </h1>

        {/* Add Post Form */}
        <form onSubmit={addPost} style={{ marginBottom: '40px' }}>
          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="title" style={{
              display: 'block',
              fontSize: '1.2rem',
              marginBottom: '8px'
            }}>
              Title:
            </label>
            <input
              type="text"
              id="title"
              name="title"
              value={newPost.title}
              onChange={handleInputChange}
              placeholder="Enter post title"
              style={{
                width: '100%',
                padding: '16px',
                border: '2px solid #ddd',
                borderRadius: '12px',
                fontSize: '16px',
                outline: 'none',
                background: 'rgba(255, 255, 255, 0.1)',
                color: 'white'
              }}
            />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="content" style={{
              display: 'block',
              fontSize: '1.2rem',
              marginBottom: '8px'
            }}>
              Content:
            </label>
            <textarea
              id="content"
              name="content"
              value={newPost.content}
              onChange={handleInputChange}
              placeholder="Enter post content"
              rows={5}
              style={{
                width: '100%',
                padding: '16px',
                border: '2px solid #ddd',
                borderRadius: '12px',
                fontSize: '16px',
                outline: 'none',
                resize: 'vertical',
                background: 'rgba(255, 255, 255, 0.1)',
                color: 'white'
              }}
            />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="author" style={{
              display: 'block',
              fontSize: '1.2rem',
              marginBottom: '8px'
            }}>
              Author:
            </label>
            <input
              type="text"
              id="author"
              name="author"
              value={newPost.author}
              onChange={handleInputChange}
              placeholder="Enter your name"
              style={{
                width: '100%',
                padding: '16px',
                border: '2px solid #ddd',
                borderRadius: '12px',
                fontSize: '16px',
                outline: 'none',
                background: 'rgba(255, 255, 255, 0.1)',
                color: 'white'
              }}
            />
          </div>
          <button
            type="submit"
            style={{
              background: '#8E24AA',
              color: 'white',
              border: 'none',
              padding: '16px 24px',
              borderRadius: '12px',
              cursor: 'pointer',
              fontSize: '16px',
              fontWeight: 'bold',
              width: '100%'
            }}
          >
            Add Post
          </button>
        </form>

        {loading && (
          <div style={{
            textAlign: 'center',
            fontSize: '1.2rem'
          }}>
            Loading posts...
          </div>
        )}

        {error && (
          <div style={{
            textAlign: 'center',
            color: '#D32F2F',
            fontSize: '1.2rem'
          }}>
            Error: {error}
          </div>
        )}

        {/* Posts List */}
        <div>
          {posts.length === 0 ? (
            <div style={{
              textAlign: 'center',
              fontSize: '1.2rem',
              padding: '40px 20px'
            }}>
              No posts yet. Add one above!
            </div>
          ) : (
            posts.map(post => (
              <div
                key={post.id}
                style={{
                  background: 'rgba(255, 255, 255, 0.1)',
                  borderRadius: '12px',
                  padding: '20px',
                  marginBottom: '20px',
                  backdropFilter: 'blur(10px)'
                }}
              >
                <h2 style={{
                  fontSize: '1.5rem',
                  marginBottom: '10px'
                }}>
                  {post.title}
                </h2>
                <p style={{
                  fontSize: '1rem',
                  marginBottom: '15px',
                  lineHeight: '1.6'
                }}>
                  {post.content}
                </p>
                <div style={{
                  fontSize: '0.9rem',
                  color: '#ddd'
                }}>
                  By {post.author} on {post.date}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}`
}

function generateBlogPreview(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Blog</title>
  <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
  <div id="root"></div>
  <script type="text/babel">
    const { useState, useEffect } = React;

    function Blog() {
      const [posts, setPosts] = useState([]);
      const [newPost, setNewPost] = useState({
        title: '',
        content: '',
        author: ''
      });
      const [loading, setLoading] = useState(false);
      const [error, setError] = useState(null);

      useEffect(() => {
        const fetchPosts = async () => {
          setLoading(true);
          setError(null);
          try {
            await new Promise(resolve => setTimeout(resolve, 1000));
            const mockPosts = [
              {
                id: 1,
                title: 'First Post',
                content: 'This is the first post content.',
                author: 'John Doe',
                date: '2024-01-01'
              },
              {
                id: 2,
                title: 'Second Post',
                content: 'This is the second post content.',
                author: 'Jane Smith',
                date: '2024-01-05'
              }
            ];
            setPosts(mockPosts);
          } catch (err) {
            setError(err.message);
            setPosts([]);
          } finally {
            setLoading(false);
          }
        };

        fetchPosts();
      }, []);

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewPost(prev => ({
          ...prev,
          [name]: value
        }));
      };

      const addPost = (e) => {
        e.preventDefault();
        if (newPost.title.trim() && newPost.content.trim() && newPost.author.trim()) {
          const post = {
            id: Date.now(),
            title: newPost.title.trim(),
            content: newPost.content.trim(),
            author: newPost.author.trim(),
            date: new Date().toISOString().slice(0, 10)
          };
          setPosts([post, ...posts]);
          setNewPost({
            title: '',
            content: '',
            author: ''
          });
        }
      };

      return (
        <div style={{
          minHeight: '100vh',
          background: 'linear-gradient(135deg, #6441A5 0%, #2A0845 100%)',
          padding: '40px 20px',
          fontFamily: 'system-ui, -apple-system, sans-serif',
          color: 'white'
        }}>
          <div style={{
            maxWidth: '800px',
            margin: '0 auto',
            background: 'rgba(255, 255, 255, 0.1)',
            borderRadius: '20px',
            padding: '40px',
            boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
            backdropFilter: 'blur(10px)'
          }}>
            <h1 style={{
              fontSize: '3rem',
              fontWeight: 'bold',
              marginBottom: '30px',
              textAlign: 'center'
            }}>
              📝 My Blog
            </h1>

            <form onSubmit={addPost} style={{ marginBottom: '40px' }}>
              <div style={{ marginBottom: '20px' }}>
                <label htmlFor="title" style={{
                  display: 'block',
                  fontSize: '1.2rem',
                  marginBottom: '8px'
                }}>
                  Title:
                </label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={newPost.title}
                  onChange={handleInputChange}
                  placeholder="Enter post title"
                  style={{
                    width: '100%',
                    padding: '16px',
                    border: '2px solid #ddd',
                    borderRadius: '12px',
                    fontSize: '16px',
                    outline: 'none',
                    background: 'rgba(255, 255, 255, 0.1)',
                    color: 'white'
                  }}
                />
              </div>
              <div style={{ marginBottom: '20px' }}>
                <label htmlFor="content" style={{
                  display: 'block',
                  fontSize: '1.2rem',
                  marginBottom: '8px'
                }}>
                  Content:
                </label>
                <textarea
                  id="content"
                  name="content"
                  value={newPost.content}
                  onChange={handleInputChange}
                  placeholder="Enter post content"
                  rows={5}
                  style={{
                    width: '100%',
                    padding: '16px',
                    border: '2px solid #ddd',
                    borderRadius: '12px',
                    fontSize: '16px',
                    outline: 'none',
                    resize: 'vertical',
                    background: 'rgba(255, 255, 255, 0.1)',
                    color: 'white'
                  }}
                />
              </div>
              <div style={{ marginBottom: '20px' }}>
                <label htmlFor="author" style={{
                  display: 'block',
                  fontSize: '1.2rem',
                  marginBottom: '8px'
                }}>
                  Author:
                </label>
                <input
                  type="text"
                  id="author"
                  name="author"
                  value={newPost.author}
                  onChange={handleInputChange}
                  placeholder="Enter your name"
                  style={{
                    width: '100%',
                    padding: '16px',
                    border: '2px solid #ddd',
                    borderRadius: '12px',
                    fontSize: '16px',
                    outline: 'none',
                    background: 'rgba(255, 255, 255, 0.1)',
                    color: 'white'
                  }}
                />
              </div>
              <button
                type="submit"
                style={{
                  background: '#8E24AA',
                  color: 'white',
                  border: 'none',
                  padding: '16px 24px',
                  borderRadius: '12px',
                  cursor: 'pointer',
                  fontSize: '16px',
                  fontWeight: 'bold',
                  width: '100%'
                }}
              >
                Add Post
              </button>
            </form>

            {loading && (
              <div style={{
                textAlign: 'center',
                fontSize: '1.2rem'
              }}>
                Loading posts...
              </div>
            )}

            {error && (
              <div style={{
                textAlign: 'center',
                color: '#D32F2F',
                fontSize: '1.2rem'
              }}>
                Error: {error}
              </div>
            )}

            <div>
              {posts.length === 0 ? (
                <div style={{
                  textAlign: 'center',
                  fontSize: '1.2rem',
                  padding: '40px 20px'
                }}>
                  No posts yet. Add one above!
                </div>
              ) : (
                posts.map(post => (
                  <div
                    key={post.id}
                    style={{
                      background: 'rgba(255, 255, 255, 0.1)',
                      borderRadius: '12px',
                      padding: '20px',
                      marginBottom: '20px',
                      backdropFilter: 'blur(10px)'
                    }}
                  >
                    <h2 style={{
                      fontSize: '1.5rem',
                      marginBottom: '10px'
                    }}>
                      {post.title}
                    </h2>
                    <p style={{
                      fontSize: '1rem',
                      marginBottom: '15px',
                      lineHeight: '1.6'
                    }}>
                      {post.content}
                    </p>
                    <div style={{
                      fontSize: '0.9rem',
                      color: '#ddd'
                    }}>
                      By {post.author} on {post.date}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      );
    }

    ReactDOM.render(<Blog />, document.getElementById('root'));
  </script>
</body>
</html>`
}

function generatePortfolioCode(): string {
  return `'use client'
import { useState } from 'react'

interface Project {
  id: number
  name: string
  description: string
  imageUrl: string
  link: string
}

export default function Portfolio() {
  const [projects, setProjects] = useState<Project[]>([
    {
      id: 1,
      name: 'Project 1',
      description: 'A brief description of project 1.',
      imageUrl: 'https://via.placeholder.com/400x300',
      link: '#'
    },
    {
      id: 2,
      name: 'Project 2',
      description: 'A brief description of project 2.',
      imageUrl: 'https://via.placeholder.com/400x300',
      link: '#'
    }
  ])

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #007991 0%, #78ffd6 100%)',
      padding: '40px 20px',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      color: '#333'
    }}>
      <div style={{
        maxWidth: '960px',
        margin: '0 auto',
        background: 'rgba(255, 255, 255, 0.9)',
        borderRadius: '20px',
        padding: '40px',
        boxShadow: '0 20px 40px rgba(0,0,0,0.1)'
      }}>
        <header style={{
          textAlign: 'center',
          marginBottom: '40px'
        }}>
          <h1 style={{
            fontSize: '3rem',
            fontWeight: 'bold',
            color: '#004d61',
            marginBottom: '10px'
          }}>
            My Portfolio
          </h1>
          <p style={{
            fontSize: '1.2rem',
            color: '#004d61'
          }}>
            Showcasing my best work
          </p>
        </header>

        <section style={{ marginBottom: '40px' }}>
          <h2 style={{
            fontSize: '2rem',
            fontWeight: 'bold',
            color: '#004d61',
            marginBottom: '20px'
          }}>
            Projects
          </h2>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '30px'
          }}>
            {projects.map(project => (
              <div
                key={project.id}
                style={{
                  background: 'white',
                  borderRadius: '12px',
                  overflow: 'hidden',
                  boxShadow: '0 10px 20px rgba(0,0,0,0.05)',
                  transition: 'all 0.3s ease'
                }}
              >
                <img
                  src={project.imageUrl || "/placeholder.svg"}
                  alt={project.name}
                  style={{
                    width: '100%',
                    height: '200px',
                    objectFit: 'cover'
                  }}
                />
                <div style={{
                  padding: '20px'
                }}>
                  <h3 style={{
                    fontSize: '1.5rem',
                    fontWeight: 'bold',
                    color: '#004d61',
                    marginBottom: '10px'
                  }}>
                    {project.name}
                  </h3>
                  <p style={{
                    fontSize: '1rem',
                    color: '#333',
                    lineHeight: '1.6'
                  }}>
                    {project.description}
                  </p>
                  <a
                    href={project.link}
                    style={{
                      display: 'inline-block',
                      marginTop: '15px',
                      background: '#007991',
                      color: 'white',
                      padding: '10px 20px',
                      borderRadius: '8px',
                      textDecoration: 'none',
                      fontWeight: 'bold'
                    }}
                  >
                    View Project
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>

        <footer style={{
          textAlign: 'center',
          marginTop: '40px',
          color: '#004d61'
        }}>
          <p>
            © {new Date().getFullYear()} My Portfolio
          </p>
        </footer>
      </div>
    </div>
  )
}`
}

function generatePortfolioPreview(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Portfolio</title>
  <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
  <div id="root"></div>
  <script type="text/babel">
    const { useState } = React;

    function Portfolio() {
      const [projects, setProjects] = useState([
        {
          id: 1,
          name: 'Project 1',
          description: 'A brief description of project 1.',
          imageUrl: 'https://via.placeholder.com/400x300',
          link: '#'
        },
        {
          id: 2,
          name: 'Project 2',
          description: 'A brief description of project 2.',
          imageUrl: 'https://via.placeholder.com/400x300',
          link: '#'
        }
      ]);

      return (
        <div style={{
          minHeight: '100vh',
          background: 'linear-gradient(135deg, #007991 0%, #78ffd6 100%)',
          padding: '40px 20px',
          fontFamily: 'system-ui, -apple-system, sans-serif',
          color: '#333'
        }}>
          <div style={{
            maxWidth: '960px',
            margin: '0 auto',
            background: 'rgba(255, 255, 255, 0.9)',
            borderRadius: '20px',
            padding: '40px',
            boxShadow: '0 20px 40px rgba(0,0,0,0.1)'
          }}>
            <header style={{
              textAlign: 'center',
              marginBottom: '40px'
            }}>
              <h1 style={{
                fontSize: '3rem',
                fontWeight: 'bold',
                color: '#004d61',
                marginBottom: '10px'
              }}>
                My Portfolio
              </h1>
              <p style={{
                fontSize: '1.2rem',
                color: '#004d61'
              }}>
                Showcasing my best work
              </p>
            </header>

            <section style={{ marginBottom: '40px' }}>
              <h2 style={{
                fontSize: '2rem',
                fontWeight: 'bold',
                color: '#004d61',
                marginBottom: '20px'
              }}>
                Projects
              </h2>
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
                gap: '30px'
              }}>
                {projects.map(project => (
                  <div
                    key={project.id}
                    style={{
                      background: 'white',
                      borderRadius: '12px',
                      overflow: 'hidden',
                      boxShadow: '0 10px 20px rgba(0,0,0,0.05)',
                      transition: 'all 0.3s ease'
                    }}
                  >
                    <img
                      src={project.imageUrl || "/placeholder.svg"}
                      alt={project.name}
                      style={{
                        width: '100%',
                        height: '200px',
                        objectFit: 'cover'
                      }}
                    />
                    <div style={{
                      padding: '20px'
                    }}>
                      <h3 style={{
                        fontSize: '1.5rem',
                        fontWeight: 'bold',
                        color: '#004d61',
                        marginBottom: '10px'
                      }}>
                        {project.name}
                      </h3>
                      <p style={{
                        fontSize: '1rem',
                        color: '#333',
                        lineHeight: '1.6'
                      }}>
                        {project.description}
                      </p>
                      <a
                        href={project.link}
                        style={{
                          display: 'inline-block',
                          marginTop: '15px',
                          background: '#007991',
                          color: 'white',
                          padding: '10px 20px',
                          borderRadius: '8px',
                          textDecoration: 'none',
                          fontWeight: 'bold'
                        }}
                      >
                        View Project
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <footer style={{
              textAlign: 'center',
              marginTop: '40px',
              color: '#004d61'
            }}>
              <p>
                © {new Date().getFullYear()} My Portfolio
              </p>
            </footer>
          </div>
        </div>
      );
    }

    ReactDOM.render(<Portfolio />, document.getElementById('root'));
  </script>
</body>
</html>`
}

function generateCounterCodeFunc(prompt: string): string {
  return `'use client'
import { useState } from 'react'

export default function Counter() {
  const [count, setCount] = useState(0)

  const increment = () => {
    setCount(count + 1)
  }

  const decrement = () => {
    setCount(count - 1)
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      color: 'white'
    }}>
      <h1 style={{
        fontSize: '3rem',
        fontWeight: 'bold',
        marginBottom: '30px',
        textAlign: 'center'
      }}>
        Simple Counter
      </h1>
      <div style={{
        fontSize: '5rem',
        fontWeight: 'bold',
        marginBottom: '40px',
        textAlign: 'center'
      }}>
        {count}
      </div>
      <div style={{
        display: 'flex',
        gap: '20px'
      }}>
        <button onClick={increment} style={{
          background: '#fff',
          color: '#f5576c',
          border: 'none',
          padding: '15px 30px',
          borderRadius: '10px',
          fontSize: '1.2rem',
          fontWeight: 'bold',
          cursor: 'pointer'
        }}>
          Increment
        </button>
        <button onClick={decrement} style={{
          background: '#fff',
          color: '#f5576c',
          border: 'none',
          padding: '15px 30px',
          borderRadius: '10px',
          fontSize: '1.2rem',
          fontWeight: 'bold',
          cursor: 'pointer'
        }}>
          Decrement
        </button>
      </div>
    </div>
  )
}
`
}

function generateCounterPreviewFunc(prompt: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Simple Counter</title>
  <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
  <div id="root"></div>
  <script type="text/babel">
    const { useState } = React;

    function Counter() {
      const [count, setCount] = useState(0);

      const increment = () => {
        setCount(count + 1);
      };

      const decrement = () => {
        setCount(count - 1);
      };

      return (
        <div style={{
          minHeight: '100vh',
          background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          fontFamily: 'system-ui, -apple-system, sans-serif',
          color: 'white'
        }}>
          <h1 style={{
            fontSize: '3rem',
            fontWeight: 'bold',
            marginBottom: '30px',
            textAlign: 'center'
          }}>
            Simple Counter
          </h1>
          <div style={{
            fontSize: '5rem',
            fontWeight: 'bold',
            marginBottom: '40px',
            textAlign: 'center'
          }}>
            {count}
          </div>
          <div style={{
            display: 'flex',
            gap: '20px'
          }}>
            <button onClick={increment} style={{
              background: '#fff',
              color: '#f5576c',
              border: 'none',
              padding: '15px 30px',
              borderRadius: '10px',
              fontSize: '1.2rem',
              fontWeight: 'bold',
              cursor: 'pointer'
            }}>
              Increment
            </button>
            <button onClick={decrement} style={{
              background: '#fff',
              color: '#f5576c',
              border: 'none',
              padding: '15px 30px',
              borderRadius: '10px',
              fontSize: '1.2rem',
              fontWeight: 'bold',
              cursor: 'pointer'
            }}>
              Decrement
            </button>
          </div>
        </div>
      );
    }

    ReactDOM.render(<Counter />, document.getElementById('root'));
  </script>
</body>
</html>`
}

export function GET() {
  return NextResponse.json({ message: "Hello from the API!" })
}
