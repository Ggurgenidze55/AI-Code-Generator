"use client"

import type React from "react"

import { useState } from "react"

interface GeneratedProject {
  code: string
  preview: string
  success: boolean
}

export default function Home() {
  const [prompt, setPrompt] = useState("")
  const [loading, setLoading] = useState(false)
  const [project, setProject] = useState<GeneratedProject | null>(null)
  const [error, setError] = useState("")

  const generateProject = async () => {
    if (!prompt.trim() || loading) return

    setLoading(true)
    setError("")
    setProject(null)

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ prompt: prompt.trim() }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        setProject(data)
      } else {
        throw new Error(data.error || "Generation failed")
      }
    } catch (err: any) {
      console.error("Generation error:", err)
      setError(err.message || "Something went wrong. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && e.ctrlKey) {
      generateProject()
    }
  }

  const quickPrompts = [
    "Create a landing page for a startup",
    "Build a todo app with React",
    "Make a calculator app",
    "Create a weather dashboard",
    "Build a blog homepage",
    "Create a portfolio website",
  ]

  const resetProject = () => {
    setProject(null)
    setError("")
  }

  if (project) {
    return (
      <div style={{ minHeight: "100vh", background: "#f8f9fa" }}>
        {/* Header */}
        <header
          style={{
            background: "#fff",
            borderBottom: "1px solid #e1e5e9",
            padding: "16px 0",
          }}
        >
          <div className="container">
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <button onClick={resetProject} className="btn" style={{ background: "#6c757d" }}>
                  ← Back
                </button>
                <h1 style={{ margin: 0, fontSize: "1.5rem", fontWeight: "600" }}>Generated Project</h1>
              </div>
              <div
                style={{
                  background: "#28a745",
                  color: "white",
                  padding: "8px 16px",
                  borderRadius: "20px",
                  fontSize: "14px",
                  fontWeight: "500",
                }}
              >
                ✅ Generated Successfully
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="container" style={{ padding: "40px 20px" }}>
          <div className="grid grid-2" style={{ gap: "30px", alignItems: "start" }}>
            {/* Preview */}
            <div>
              <h2
                style={{
                  marginBottom: "16px",
                  fontSize: "1.25rem",
                  fontWeight: "600",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                }}
              >
                📱 Live Preview
              </h2>
              <div className="preview-container" style={{ height: "600px" }}>
                <iframe
                  srcDoc={project.preview}
                  style={{
                    width: "100%",
                    height: "100%",
                    border: "none",
                    borderRadius: "12px",
                  }}
                  title="Preview"
                  sandbox="allow-scripts allow-same-origin"
                />
              </div>
            </div>

            {/* Code */}
            <div>
              <h2
                style={{
                  marginBottom: "16px",
                  fontSize: "1.25rem",
                  fontWeight: "600",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                }}
              >
                💻 Generated Code
              </h2>
              <div className="code-container" style={{ height: "600px" }}>
                {project.code}
              </div>
              <button
                onClick={() => navigator.clipboard.writeText(project.code)}
                className="btn"
                style={{ marginTop: "16px", background: "#17a2b8" }}
              >
                📋 Copy Code
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{ minHeight: "100vh", background: "#f8f9fa" }}>
      {/* Header */}
      <header
        style={{
          background: "#fff",
          borderBottom: "1px solid #e1e5e9",
          padding: "20px 0",
        }}
      >
        <div className="container">
          <div style={{ textAlign: "center" }}>
            <h1
              style={{
                fontSize: "2.5rem",
                fontWeight: "700",
                margin: "0 0 8px 0",
                background: "linear-gradient(135deg, #007bff, #6610f2)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              🤖 AI Code Generator
            </h1>
            <p
              style={{
                fontSize: "1.2rem",
                color: "#6c757d",
                margin: 0,
              }}
            >
              Generate React applications with AI
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container" style={{ padding: "60px 20px" }}>
        <div style={{ maxWidth: "800px", margin: "0 auto" }}>
          {/* Input Section */}
          <div className="card" style={{ marginBottom: "40px" }}>
            <h2
              style={{
                fontSize: "1.5rem",
                fontWeight: "600",
                marginBottom: "20px",
                textAlign: "center",
              }}
            >
              What would you like to build?
            </h2>

            <div style={{ marginBottom: "20px" }}>
              <textarea
                className="input textarea"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Describe your app idea... (e.g., 'Create a landing page for a tech startup')"
                disabled={loading}
                style={{ marginBottom: "16px" }}
              />

              <button
                onClick={generateProject}
                disabled={loading || !prompt.trim()}
                className="btn btn-primary"
                style={{
                  width: "100%",
                  padding: "16px",
                  fontSize: "18px",
                  fontWeight: "600",
                }}
              >
                {loading ? (
                  <>
                    <span className="loading" style={{ marginRight: "8px" }}></span>
                    Generating...
                  </>
                ) : (
                  "🚀 Generate Code"
                )}
              </button>

              <p
                style={{
                  textAlign: "center",
                  color: "#6c757d",
                  fontSize: "14px",
                  marginTop: "8px",
                }}
              >
                Press Ctrl+Enter to generate
              </p>
            </div>

            {error && (
              <div className="error">
                <strong>Error:</strong> {error}
              </div>
            )}
          </div>

          {/* Quick Examples */}
          <div>
            <h3
              style={{
                fontSize: "1.25rem",
                fontWeight: "600",
                marginBottom: "20px",
                textAlign: "center",
              }}
            >
              💡 Try these examples:
            </h3>

            <div className="grid grid-3">
              {quickPrompts.map((quickPrompt, index) => (
                <button
                  key={index}
                  onClick={() => setPrompt(quickPrompt)}
                  className="card"
                  style={{
                    border: "2px solid #e1e5e9",
                    background: "#fff",
                    cursor: "pointer",
                    textAlign: "left",
                    padding: "20px",
                    transition: "all 0.2s ease",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = "#007bff"
                    e.currentTarget.style.background = "#f8f9ff"
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = "#e1e5e9"
                    e.currentTarget.style.background = "#fff"
                  }}
                >
                  <div
                    style={{
                      fontSize: "16px",
                      fontWeight: "500",
                      color: "#333",
                    }}
                  >
                    {quickPrompt}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer
        style={{
          background: "#fff",
          borderTop: "1px solid #e1e5e9",
          padding: "40px 0",
          marginTop: "60px",
        }}
      >
        <div className="container">
          <div style={{ textAlign: "center", color: "#6c757d" }}>
            <p style={{ margin: "0 0 8px 0" }}>Built with Next.js, React, and TypeScript</p>
            <p style={{ margin: 0, fontSize: "14px" }}>Generate beautiful React applications with AI assistance</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
